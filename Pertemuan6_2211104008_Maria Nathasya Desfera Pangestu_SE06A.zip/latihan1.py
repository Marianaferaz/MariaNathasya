sisi = int (input ("masukkan sisi : "))

def hitung_keliling_persegi(sisi):
    keliling = 4*sisi
    print ("keliling dari persegi : {}".format(keliling) )

def hitung_luas_persegi(sisi):
    luas = sisi*sisi
    print("luas persegi : {} ".format(luas)) 

hitung_keliling_persegi(sisi)
hitung_luas_persegi(sisi) 