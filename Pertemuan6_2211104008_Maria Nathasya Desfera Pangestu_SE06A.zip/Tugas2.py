import math

def hitung_luas_lingkaran(jari_jari):
    luas = math.pi * jari_jari**2
    return luas

def hitung_keliling_lingkaran(jari_jari):
    keliling = 2 * math.pi * jari_jari
    return keliling

def main():
    jari_jari = float(input("Masukkan jari-jari lingkaran: "))

    luas = hitung_luas_lingkaran(jari_jari)
    keliling = hitung_keliling_lingkaran(jari_jari)
    
    print("\nKeliling lingkaran:", keliling)
    print("Luas lingkaran:", luas)
    

main()
