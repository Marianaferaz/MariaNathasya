def nilai(nilai1, nilai2):
    if(nilai1>nilai2):
        print(nilai)
    elif(nilai1==nilai2):
        print("tidak ada bilangan yang lebih besar")
    else:
        print(nilai2)

bilangan = int(input("masukkan bilangan 1: "))
bilangan2 = int(input("masukkan bilangan 2: "))
print("Bilangan yang paling besar adalah: ")
nilai(bilangan, bilangan2)
