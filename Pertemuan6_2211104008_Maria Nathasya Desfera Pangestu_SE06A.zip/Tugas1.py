def cek_ganjil_genap(bilangan):
    if bilangan % 2 == 0:
        print(bilangan, "adalah bilangan genap")
    else:
        print(bilangan, "adalah bilangan ganjil")

def main():
    bilangan = int(input("Masukkan bilangan: "))
    cek_ganjil_genap(bilangan)

main()