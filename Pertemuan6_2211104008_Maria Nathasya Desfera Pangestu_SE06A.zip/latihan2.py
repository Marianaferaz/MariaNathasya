def hitung_keliling_persegi(sisi):
    keliling = 4*sisi
    return keliling

def hitung_luas_persegi(sisi):
    luas = sisi*sisi
    return luas

sisi = int (input("masukkan sisi : "))

print (f"keliling persegi : {hitung_keliling_persegi(sisi)}")
print (f"luas persegi : {hitung_luas_persegi(sisi)} ")

print (hitung_keliling_persegi(sisi))
print (hitung_luas_persegi(sisi))