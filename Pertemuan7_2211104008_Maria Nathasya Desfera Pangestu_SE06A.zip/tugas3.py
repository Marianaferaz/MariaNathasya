def insertion_sort(arr):
    for i in range(1, len(arr)):
        key = arr[i]
        j = i - 1
        while j >= 0 and arr[j] > key:
            arr[j + 1] = arr[j]
            j -= 1
        arr[j + 1] = key

jumlah_buku = int(input("Masukkan Total Buku: "))

daftar_buku = []
for i in range(jumlah_buku):
    judul = input("Masukkan Judul Buku ke-{}: ".format(i + 1))
    daftar_buku.append(judul)

print("\nUrutkan?")
print("1. Insertion Ascending")
print("2. Descending")
pilihan = int(input("Pilih: "))

if pilihan == 1:
    insertion_sort(daftar_buku)
elif pilihan == 2:
    insertion_sort(daftar_buku)
    daftar_buku.reverse()
else:
    print("Pilihan tidak valid.")

print("\nDaftar buku setelah diurutkan:")
for i, buku in enumerate(daftar_buku, start=1):
    print("Judul Buku ke-{}: {}".format(i, buku))