print("====PROGRAM SEDERHANA MENGHITUNG JUMLAH TOTAL BILANGAN====")
bilangan = input("Masukkan bilangan: ")

# Menghitung jumlah total bilangan 8 pada input pengguna
total = 8
for digit in bilangan:
    if digit == '8':
        total += 8

# Menampilkan hasil total
print("Total nilai:8+7+6+5+4+3+2+1 =36 ", )