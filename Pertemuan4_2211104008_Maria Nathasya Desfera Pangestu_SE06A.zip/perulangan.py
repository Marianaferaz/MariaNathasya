#for range max
#for i in range(10):
    #print("Hallo World!")

#for range min, max
for i in range(1, 10):
    print(f"Perulangan ke-{i}")
    if i == 5:
        continue

    print(i)

#for range min, max, step
#for i in range(0, 20, 2):
    #print(f"Step ke- {i}")

    


    