Array = []
total = 0
x = int(input("Masukkan jumlah mata kuliah: "))
for i in range(x):
    Array.append(input(f"Masukkan mata kuliah ke-{(i+1)}: ")) 
    total = total + int(Array[i])

hasil = total / x
predikat = ""

if hasil < 100 and hasil >= 90: 
    predikat = "A"
elif hasil < 90 and hasil >= 70:
    predikat = "B"
elif hasil < 70 and hasil >= 50:
    predikat = "C" 
elif hasil < 50 and hasil >= 30:
    predikat = "D"
elif hasil < 30 and hasil >= 0: 
    predikat = "E"
else:
    predikat = "Tidak Valid"

if predikat == "Tidak Valid": 
    print("Tidak Valid")
else:
    print("Hasil Predikat "+predikat+ " dengan nilai:") 
    for i in range(x):
        print("Mata kuliah ke-%d: %s" % ((1+1), Array[i]))
