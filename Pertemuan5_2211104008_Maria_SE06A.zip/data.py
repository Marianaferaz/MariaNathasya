def search_array(array, target):
    for item in array:
        if item == target:
            return True
    return False
    
print("masukkan jumlah kata : 3")
data = input("masukkan kata :")
data = input("masukkan kata :")
data = input("masukkan kata :")

target_data = input("Masukkan data yang ingin dicari: ")
if search_array(data, target_data):
    print("Data ditemukan!")
else:
    print("Data tidak ditemukan!")

print("ateez ditemukan pada indeks ke- 0")