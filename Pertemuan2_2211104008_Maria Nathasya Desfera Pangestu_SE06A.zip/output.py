print("Hallo, selamat pagi!") #cetak string secara langsung

belajar = "Belajar Python"
print(belajar) #cetak string menggunakan variabel

nama = "Maria"
print("Selamat pagi{}".format (nama))#cetak string fungsi format)

Maria = "Nasi goreng"
San = "Ramen"
Yeosang = "Ayam goreng"
print(f"Makanan favorit = {Maria}")
print(f"Makanan favorit = {San}")
print(f"Makanan favorit = {Yeosang}")

#print(Makanan favorit Maria = {}".format (Maria))
#print(Makanan favorit San = {}".format (San))
#print(Makanan favorit Yeosang = {}".format (Yeosang))
#print(Makanan favorit Yeosang \n = {}".format (Yeosang))

