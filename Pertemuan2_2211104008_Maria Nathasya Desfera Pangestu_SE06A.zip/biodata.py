nama_lengkap = "Maria Nathasya Desfera Pangestu"
ttl = "Magelang, 12 Desember 2003"
alamat = "Jl. Sidodadi No. 1 Samudera, Purwokerto Kidul"
no_hp = "082363242595"
program_study = "Rekayasa Perangkat Lunak"
hobi = "Menonton film"

#input integer
print("Biodata")
print("Nama Lengkap: Maria Nathasya Desfera Pangestu")
print("TTL: Magelang, 12 Desember 2003 ")
print("Alamat: Jl. Sidodadi No. 1 Samudera, Purwokerto Kidul ")
print("No. hp: 082363242595 ")
print("Program Study: Rekayasa Perangkat Lunak ")
print("Hobi: Menonton film ")
