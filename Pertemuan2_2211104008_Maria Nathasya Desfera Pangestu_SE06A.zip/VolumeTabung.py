jari_jari = 2
tinggi = 10
pi = 3.14
volume_tabung = pi * jari_jari * jari_jari * tinggi
print("Volume tabung dengan jari-jari", jari_jari, "dan tinggi", tinggi, "adalah", volume_tabung)