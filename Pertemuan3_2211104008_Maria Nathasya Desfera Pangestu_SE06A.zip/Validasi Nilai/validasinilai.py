bilangan_pertama = float(input("Masukkan bilangan pertama: "))
bilangan_kedua = float(input("Masukkan bilangan kedua: "))

if bilangan_kedua == 0:
    print("Tidak dapat melakukan pembagian dengan nol.")
else:
    hasil = bilangan_pertama / bilangan_kedua
    print("Hasil pembagian adalah", hasil)