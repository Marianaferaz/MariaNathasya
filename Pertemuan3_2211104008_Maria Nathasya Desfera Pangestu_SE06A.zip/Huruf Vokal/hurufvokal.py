#huruf vokal konsonan
user = input("Masukkan sebuah huruf: ")
if user.isalpha():
    if user.lower() in ['a', 'i', 'u', 'e', 'o']:
        print("Huruf vokal")
    else:
        print("Huruf konsonan")
else:
    print("Inputan bukan huruf")